# StudyHub — PC16 Week 14 Flutter Static UI

- **Student:** Carl John S. Villasis (BSIT 3.3)
- **Course:** PC16 – Mobile Development with Lab (National Teachers College)
- **Figma Reference:** https://www.figma.com/design/5bcX07QPTYezD0gLgPsOWL/Villasis_CarlJohn_Week14

## Project Overview
A two-screen Flutter static UI prototype for **StudyHub** built with `MaterialApp`, shared `ThemeData`, `StatelessWidget` classes, `Row`, `Column`, `Stack`/`Positioned`, and local `Image.asset` rendering.

## Screens Included
1. **Screen 1 (`lib/screens/welcome_screen.dart`):** Welcome / Login screen with local banner image, greeting, and static email/password fields.
2. **Screen 2 (`lib/screens/dashboard_screen.dart`):** Student Dashboard featuring a `Stack` course banner (`WEEK 14 LAB` badge and title overlay), summary stat cards, and enrolled BSIT 3.3 subjects.

## How to Preview Both Screens (Without Navigation Logic)
Open `lib/main.dart` and switch the `home:` property inside `MaterialApp`:

- **Preview Screen 1 (`WelcomeScreen`):**
  ```dart
  home: const WelcomeScreen(),
  // home: const DashboardScreen(),
  ```

- **Preview Screen 2 (`DashboardScreen`):**
  ```dart
  // home: const WelcomeScreen(),
  home: const DashboardScreen(),
  ```

Save the file (`Cmd + S`) to hot-reload the active screen.
